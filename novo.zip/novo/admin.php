<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EngSoft Notes | Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Fonte -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="css/admin.css">
    <link rel="shortcut icon" href="img/b.png" type="image/x-icon">
</head>
<body>

<div class="layout">

<?php include 'sidebar.php'; ?>


    <!-- CONTEÚDO -->
    <main class="main-content">
        <div class="container-fluid p-4">

            <!-- TOPO -->
            <header class="d-flex justify-content-between align-items-center mb-5">
                <div>
                    <span class="text-muted">Matérias /</span>
                    <strong>Matérias</strong>
                </div>

                <div class="d-flex align-items-center gap-3">
                    <div class="search-box">
                        <i data-lucide="search"></i>
                        <input type="text" placeholder="Pesquisar...">
                    </div>
                    <img src="https://via.placeholder.com/40" class="rounded-circle border">
                </div>
            </header>

            <!-- CARDS DE CIMA -->
            <div class="row g-4 mb-5">
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon bg-blue-soft"><i data-lucide="book"></i></div>
                        <p class="stats-label mt-3">Matérias cadastradas</p>
                        <h3 class="stats-number">1</h3>
                        <button class="btn-add-subject">+ Adicionar Matéria</button>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon bg-green-soft"><i data-lucide="file-text"></i></div>
                        <p class="stats-label mt-3">Conteúdos criados</p>
                        <h3 class="stats-number">0</h3>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon bg-orange-soft"><i data-lucide="help-circle"></i></div>
                        <p class="stats-label mt-3">Perguntas de revisão</p>
                        <h3 class="stats-number">0</h3>
                        <i data-lucide="lock" class="lock-icon"></i>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="stats-icon bg-purple-soft"><i data-lucide="calendar"></i></div>
                        <p class="stats-label mt-3">Hoje</p>
                        <h3 class="stats-number">03 Jan</h3>
                    </div>
                </div>
            </div>

            <!-- PARTE DE BAIXO -->
            <div class="row g-4">
                <div class="col-md-8">
                    <h5 class="fw-bold mb-4">Gerenciar Matérias</h5>

                    <div class="subject-card">
                        <img src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800">
                        <div class="p-4">
                            <h6 class="fw-bold mb-1">Algoritmos e Programação</h6>
                            <p class="text-muted small">Lógica, algoritmos e fundamentos</p>

                            <div class="d-flex gap-2 mt-3">
                                <button class="btn btn-primary btn-sm">Editar</button>
                                <button class="btn btn-outline-danger btn-sm">Excluir</button>
                                <button class="btn btn-light btn-sm">Conteúdo +</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <h5 class="fw-bold mb-4">Atividades Recentes</h5>

                    <div class="activity-box p-4">
                        <div class="activity-item d-flex gap-3">
                            <div class="avatar-icon">
                                <i data-lucide="user"></i>
                            </div>
                            <div>
                                <p class="mb-0 small">
                                    <strong>User</strong> criou a matéria <b>POO</b>
                                </p>
                                <span class="text-muted small">há 2 horas</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>
</div>

<!-- ICONES -->
<script src="https://unpkg.com/lucide@latest"></script>
<script>
    lucide.createIcons();
</script>

</body>
</html>
