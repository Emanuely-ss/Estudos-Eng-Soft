<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/materias.css">
    <link rel="icon" href="img/b.png" type="image/x-icon">
    <title>EngSoft | Matérias</title>
</head>
<body>
<nav class="navbar navbar-light bg-light px-4">
  <div class="container-fluid d-flex align-items-center justify-content-between">

    <!-- ESQUERDA: LOGO + BREADCRUMB -->
    <div class="d-flex align-items-center gap-3">
      <img src="img/c.png" alt="Logo" class="logo">

      <div class="breadcrumb-custom">
        <span class="text-muted">Matérias /</span>
        <strong> Matérias</strong>
      </div>
    </div>

    <!-- DIREITA: BUSCA -->
    <div class="d-flex align-items-center gap-2">
      <i class="bi bi-search"></i>
      <input
        type="text"
        class="form-control search-input"
        placeholder="Pesquisar..."
      >
    </div>

  </div>
</nav>
<div class="container my-4">
<div class="d-flex justify-content-end mb-4">
    <div class="d-flex gap-2 align-items-center filter-wrapper">
        <span class="text-muted">Ordenar por:</span>
        <select class="form-select filter-select">
            <option value="recentes">Mais recentes</option>
            <option value="antigas">Mais antigas</option>
        </select>
    </div>
</div>
  
 <div class="container my-4">
    <div class="card" style="width: 18rem;">
        <img src="img/a.png" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title">Matéria teste</h5>
            <p class="card-text">
                Some quick example text to build on the card title.
            </p>
            <a href="#" class="btn btn-primary w-100">
                Ver conteúdo
            </a>
        </div>
    </div>
  </div>
  </div>
</body>

</html>