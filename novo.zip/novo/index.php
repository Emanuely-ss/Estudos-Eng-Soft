<!DOCTYPE html>
<html lang="pt" >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EngSoft Notes</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="img/b.png" type="image/x-icon">
</head>
<body>
    <nav class="navbar navbar-expand-lg">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="#">EngSoft Notes</a>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Matérias</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Conteúdo</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Revisão</a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true">Em Breve</a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<div class="container text-center hero">
  <img src="img/logo500x500.png" class="img-fluid" width="300">
  <p class="text-muted fs-5 mx-auto" style="max-width:700px;">
    EngSoft Notes é uma plataforma de estudos em <span class="destaque">Engenharia de Software</span>,
    desenvolvida para organizar e compartilhar matérias, conteúdos e revisões acadêmicas.
  </p>
</div>
</div>
<h3 class="text-center fw-semibold mt-4 mb-3">O que você encontra aqui?</h3>
<div class="container mt-3 mb-4">
  <div class="row g-4">
    <!-- Card 1 -->
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title"> Matérias</h5>
          <p class="card-text">
            Explore todas as disciplinas do curso e descubra o que você aprende em cada uma.
          </p>
          <a href="#" class="btn btn-custom">Ver matérias</a>
        </div>
      </div>
    </div>
    <!-- Card 2 -->
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Conteúdo</h5>
          <p class="card-text">
             Conteúdos organizados por disciplina para acompanhar seus estudos.
          </p>
          <a href="#" class="btn btn-custom">Ver conteúdo</a>
        </div>
      </div>
    </div>
    <!-- Card 3 -->
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">Revisão</h5>
          <p class="card-text">
            Teste seus conhecimentos e acompanhe sua evolução.
          </p></br>
          <a href="#" class="btn btn-custom">Fazer revisão</a>
        </div>
      </div>
    </div>
  </div>
</div>
<footer class="text-center container my-3">
  © 2025 EngSoft Notes · Desenvolvido por Emanuely Sousa Silva
</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>