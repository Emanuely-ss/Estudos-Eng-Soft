<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EngSofts Notes | Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="css/login.css" rel="stylesheet">
  <link rel="shortcut icon" href="img/b.png" type="image/x-icon">
</head>
<body class="login-page">
  <main class="form-container">
        <form method="post" action="login.php">
            <img src="img/logo500x500.png" class="mb-4 d-block mx-auto" alt="logo">
            <h1 class="h3 mb-3 text-center">Sign in</h1>
    <div class="form-floating">
        <input type="text" class="form-control" id="user" name="user" placeholder="usuario" required>
        <label for="user">User</label>
    </div>
    <div class="form-floating mt-2">
        <input type="password" class="form-control" id="password" name="password" placeholder="password" required >
        <label for="password">Password</label>
    </div>
    <div class="form-check text-start my-3">
      <input class="form-check-input" type="checkbox" id="remember">
      <label class="form-check-label" for="remember">Remember me</label>
    </div>
    <button class="btn btn-login w-100 py-2" type="submit">Sign in</button>
  </form>
</main>
</body>
</html>
