    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div>
            <div class="sidebar-logo">
                <img src="img/logo.png" alt="Logo">
            </div>

            <nav class="sidebar-menu">
                <a href="materias.php" class="menu-item">
                    <i data-lucide="book-open"></i> Matérias
                </a>
                <a href="#" class="menu-item">
                    <i data-lucide="file-text"></i> Conteúdos
                </a>
                <a href="#" class="menu-item">
                    <i data-lucide="check-square"></i> Revisões
                </a>
                <a href="configuracoes.php" class="menu-item">
                    <i data-lucide="settings"></i> Configurações
                </a>
            </nav>
        </div>

        <div class="sidebar-user">
            <div class="user-info">
                <div class="avatar-icon">
                    <i data-lucide="user"></i>
                </div>
                <span>User</span>
            </div>
            <i data-lucide="chevron-right" width="16"></i>
        </div>
    </aside>
