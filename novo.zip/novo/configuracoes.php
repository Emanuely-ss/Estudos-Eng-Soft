<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>EngSoft | Configurações</title>
    <link rel="icon" href="img/b.png" type="image/x-icon">
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Fonte -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/admin.css">

</head>
<body>

<div class="layout">

    <!-- SIDEBAR -->
    <?php include 'sidebar.php'; ?>

    <!-- CONTEÚDO PRINCIPAL -->
    <div class="main-content">
        <div class="container-fluid py-4">
    
            <h1 class="fw-bold mb-4">Configurações</h1>
            <br><br>
 <div class="row g-4">

    <!-- PERFIL -->
    <div class="col-md-6">
        <div class="settings-card">
            <div class="settings-avatar">
                <i data-lucide="user"></i>
                <span class="change-photo">Alterar foto</span>
            </div>

            <h2 class="fw-bold mb-3">Perfil</h2>

            <div class="mb-3">
                <label class="form-label">Nome</label>
                <input type="text" class="form-control" name="nome">
            </div>

            <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" class="form-control" name="email">
            </div>

            <button class="btn btn-primary btn-sm">Salvar</button>
        </div>
    </div>

    <!-- SEGURANÇA -->
    <div class="col-md-6">
        <div class="settings-card">
            <div class="settings-avatar security">
                <i data-lucide="lock"></i>
            </div>

            <h6 class="fw-bold mb-3">Segurança</h6>

            <div class="mb-3">
                <label class="form-label">Senha atual</label>
                <input type="password" class="form-control" name="senha_atual">
            </div>

            <div class="mb-3">
                <label class="form-label">Nova senha</label>
                <input type="password" class="form-control" name="nova_senha">
            </div>

            <button class="btn btn-outline-primary btn-sm">Alterar senha</button>
        </div>
    </div>
  <div class="row g-4">

    <!-- PREFERÊNCIAS -->
    <div class="col-md-6">
        <div class="settings-card">
            <div class="settings-avatar">
                <i data-lucide="sliders"></i>
            </div>

            <h6 class="fw-bold mb-3">Preferências</h6>

            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" disabled>
                <label class="form-check-label">
                    Tema escuro (em breve)
                </label>
            </div>
        </div>
    </div>
            <!-- AÇÕES IMPORTANTES -->
    <div class="col-md-6">
        <div class="settings-card border-danger">
            <div class="settings-avatar security">
                <i data-lucide="alert-triangle"></i>
            </div>

            <h6 class="fw-bold mb-3 text-danger">Exclusão</h6>

            <div class="d-flex gap-3">

                <button class="btn btn-outline-danger">
                    Excluir conta
                </button>
            </div>
        </div>
    </div>
</div>
<div class="d-flex align-items-center gap-2 mb-4">
    <a href="admin.php" class="btn btn-outline-secondary btn-sm">
        ← Voltar
    </a>
</div>

<script src="https://unpkg.com/lucide@latest"></script>
<script>
    lucide.createIcons();
</script>

</body>
</html>
