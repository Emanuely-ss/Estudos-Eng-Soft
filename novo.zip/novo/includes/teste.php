<?php
require_once "db.php";

echo "Conectado com sucesso!";
